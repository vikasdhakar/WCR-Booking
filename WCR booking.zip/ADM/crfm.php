<?php

 session_start();
include('conn.php');

if (isset($_POST['Go'])) {
$nam=$_POST['nam'];
$oid=$_POST['oid'];
$omob=$_POST['omob'];
$idate=$_POST['idate'];
$odate=$_POST['odate'];
$state=$_POST['state'];
$sn=$_POST['uid'];
$ref=$_POST['ref'];
$sname=$_POST['sname'];
$ac=$_POST['ac'];
$rnom=$_POST['rnom'];
//19-01-2018 :  Room Allotment 


$favcolor =$state;

switch ($favcolor) {
    case "Confirm":
       
      $sql2= "UPDATE raild set bdate='$idate',edate='$odate',oidd='$oid',oname='$nam',onum='$omob',ref='$ref',status='1' WHERE sname='$sname' AND status='0' AND ac='$ac' AND rno='$rnom' ";
    
          if (mysqli_query($con,$sql2)) {
    $sql= "UPDATE reservation set status='$state' ,activity='1' WHERE sn='$sn'";
    
   if (mysqli_query($con,$sql)) {
    $crfm="Confirm";
    $_SESSION['crfm']=$crfm;
	header('location:../index.php');
} 

else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}
} else {
    echo "Error: " . $sql2 . "<br>" . mysqli_error($con);
}

        break;
    case "Waiting":
        $sql= "UPDATE reservation set status='$state',activity='0' WHERE sn='$sn'";
      if (mysqli_query($con,$sql)) {
    
    $crfm=" Wating";
    $_SESSION['crfm']=$crfm;
    header('location:../index.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}

        break; 
    default:
       $sql= "UPDATE reservation set status='$state',activity='0' WHERE sn='$sn'";
    
    if (mysqli_query($con,$sql)) {
    
    $crfm="Not-Confirm";
    $_SESSION['crfm']=$crfm;
    header('location:../index.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}
}

//19-01-2018 :  Room Allotment 
}




?>