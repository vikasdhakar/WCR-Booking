<?php

$con=mysqli_connect('localhost','root','','wcr');
	
	if(!$con)
		die("Unable to Connect to Database Server");

?>