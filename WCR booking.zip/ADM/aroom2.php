<?php
session_start();

  $sname=$_POST['sname'];
  $rno=$_POST['rno'];
  $ac=$_POST['ac'];
  $status=0;

 
  include ('conn.php');
   
    $sql3 = "INSERT INTO raild (sname,rno,ac,bdate,edate,oidd,oname,onum,ref,status)
            VALUES ('$sname','$rno','$ac','','','','','','','$status')";

            if ($con->query($sql3) === TRUE) {
                $last_id = $con->insert_id;
                                
                  $_SESSION['binfo'] ="Room Added Sucessfully . Room id :-  $last_id";
                  header('location:aroom.php');
            } else {
                echo "Error: " . $sql3 . "<br>" . $con->error;
                
            }
?>
