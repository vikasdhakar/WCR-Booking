<?php
$bid=$_GET["bid"];
$aid=$_GET["aid"];

 
    include ('conn.php');
     
$sql2 = "update rrail set status=0,bdate=null,edate=null,oid=null,oname=null,onum=null where id='$aid'";
    if ($conn->query($sql2) === TRUE) {
        $sql = "update brail set status=0 where id='$bid'";
                 if ($conn->query($sql) === TRUE) {
                 echo "Booking Canceled Sucessfully";
    }
    else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
    }
    else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
?>
<script type="text/javascript">
         <!--
            function Redirect() {
               window.location="index.php";
            }
            
            setTimeout('Redirect()', 1000);
         //-->
      </script>