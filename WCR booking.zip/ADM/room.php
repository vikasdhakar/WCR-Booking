<?php include ('conn.php'); ?>
<?php
session_start();
if(!isset($_SESSION['roomclear'])){

    echo "";
} 
?>

<html>
<title>Room Details</title>
    <body> 
        <center><hr>
            <a href="index.php" align="center" >MANAGE BOOKINGS</a> &nbsp; &nbsp; &nbsp;
            <a href="aroom.php" align="center" >ADD ROOMS </a> &nbsp; &nbsp; &nbsp;
            <a href="room.php" align="center">CHECK ROOMS</a> &nbsp; &nbsp; &nbsp; &nbsp;
            <a href="../index.php" align="center">LOGOUT</a>
        </center><hr>
        <script type="text/javascript">
            function confirmCen() {

                var x = confirm("Are You sure ?")
                if (x==true) {
                    return true;

                }
                else{
                    return false;
                }          }

        </script>
<div class="container" style="width:70%">
    <center>

        <p  style="background: #2196F3; color: white; text-align: center; font-size: 150%; border-radius: 5px; width: 50%; " >
<?php if (isset($_SESSION['roomclear'])) {
    echo $_SESSION['roomclear'];
    unset($_SESSION['roomclear']);
}
?></p>
 <center><b>**Note: 1 means YES and 0 means NO.</b><br><br>
</center>
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 143%;
    border: 1px solid #blue;
}

th, td {
    text-align: center;
    padding: 3px;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}
tr:nth-child(odd) {
    background-color: lightgrey;
}
</style>
            <table class="table table-bordered" border="1px"   align="center">  
                            <tr>  
                                <th>Room Id</th>  
                                <th >Station Name</th>  
                                <th >Room Number</th>  
                                <th >AC</th>  
                                <th>Status</th>  
                                <th >IN Date</th>  
                                <th >OUT Date</th>  
                                <th >Officer id</th>  
                                <th >Officer name</th>  
                                <th >Officer Number</th>
                                <th >Referenrce ID</th>  
                                <th >Action </th>  
                            </tr>  
            
            <?php
            
            $sql = "SELECT *  FROM raild  ORDER BY status DESC";
            $result = $con->query($sql);
            while($row = $result->fetch_assoc())
            {
                
                ?>
                        <tr>  
                                <td><?php echo $row['uid']; ?></td>  
                                <td><?php echo $row['sname']; ?></td>  
                                <td><?php echo $row['rno']; ?></td> 
                                <td><?php echo $row['ac']; ?></td>  
                                <td><?php echo $row['status']; ?></td>  
                                <td><?php echo $row['bdate']; ?></td>  
                                <td><?php echo $row['edate']; ?></td>  
                                <td><?php echo $row['oidd']; ?></td>  
                                <td><?php echo $row['oname']; ?></td>  
                                <td><?php echo $row['onum']; ?></td>  
                                <td><?php echo $row['ref']; ?></td>  
                                <td><a href="room2.php?aid=<?php echo $row['uid']; ?> & oidd=<?php echo $row['oidd']; ?> & ref=<?php echo $row['ref']; ?>" onclick="return confirmCen()"><span class="btn btn-danger">Clear</span></a></td>  
                        </tr>  
            <?php
            }
            ?>
            
                </table> 
        </div>
        </body>
    </html>