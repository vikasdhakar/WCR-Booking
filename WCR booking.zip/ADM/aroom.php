<?php
session_start();
if(!isset($_SESSION['binfo'])){

	echo "";
} 
?>

<hr><h1 align="center">WEST CENTRAL RAILWAY</h1><h3 align="center">KOTA DIVISION</h3><hr>
<center>
            <a href="index.php" align="center" >MANAGE BOOKINGS</a> &nbsp; &nbsp; &nbsp;
            <a href="aroom.php" align="center" >ADD ROOMS </a> &nbsp; &nbsp; &nbsp;
            <a href="room.php" align="center">CHECK ROOMS</a> &nbsp; &nbsp; &nbsp; &nbsp;
            <a href="../index.php" align="center">LOGOUT</a>
        </center><hr> <br>

<form method="post" action="aroom2.php">
		<table cellpadding="2px"; border="1" align="center" >
			
				<tr>
					<td colspan="2" align="center"><b>Add Room</b></td>
				</tr>	
				<tr>
					<td align="center">Select the REST HOUSE</td>
					<td><select name="sname">
						<option>Select the Station</option>
						<option value="bharatpur">Bharatpur</option>
						<option value="bundi" >Bundi</option>
						<option value="gangapur" >Gangapur</option>
						<option value="kota" > Kota</option>
						<option value="mandalgarh" >Mandalgarh</option>
						<option value="sawaimadhopur" >Sawaimadhopur</option>
						<option value="shamgarh" >Shamgarh</option>
						<option value="thuklakabad" >Thuklakabad</option>
					</select></td>
					
				</tr>
				<tr>
					<td align="center">Room No.</td>
					<td><input type="text" name="rno"></td>
				</tr>
				<tr>
					<td align="center">Type of Room</td>
					<td>
						<input type="radio" name="ac" value="1" >AC ROOM
						<input type="radio" name="ac" value="0" >Non-AC ROOM
					</td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="r"> &nbsp; <input type="reset"></td>
				</tr>
			
		</table>
		</form>
<center>
		<p  style="background: #2196F3; color: white; text-align: center; font-size: 150%; border-radius: 5px; width: 50%; " >   <?php if (isset($_SESSION['binfo'])) {
	echo $_SESSION['binfo'];
	unset($_SESSION['binfo']);
}
?></p>
</center>