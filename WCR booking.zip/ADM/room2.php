<?php
$aid=$_GET["aid"];
$oid=$_GET['oidd'];
$ref=$_GET['ref'];

 session_start();
	include ('conn.php');
	 
$sql2 = "UPDATE raild set bdate='',edate='',oidd='',oname='',onum='',ref='',status=0 WHERE uid='$aid'";
    if ($con->query($sql2) === TRUE) {
                 
                 $_SESSION['roomclear'] ="Room Cleared Sucessfully .   ";
                  
            }
    else {
                echo "Error: " . $sql . "<br>" . $con->error;
            }
    $sql= "UPDATE reservation set activity='0' WHERE id='$oid' AND ref='$ref'";
    
    if (mysqli_query($con,$sql)) {
    
    $crfm="Not-Confirm";
    $_SESSION['crfm']=$crfm;
    header('location:room.php');
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($con);
}
?> 