<meta name="viewport" content="width=device-width, initial-scale=1">
<?php  session_start();  ?>
 
<style type="text/css">
table{
    width: 100%;
}
table ,td ,th{border: 1px solid black; padding: 5px;  border-collapse: collapse; text-align: center; }
     
.tooltip {
    position: relative;
    display: inline-block;
    border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
    visibility: hidden;
    width: 120px;
    background-color: black;
    color: #fff;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;

    /* Position the tooltip */
    position: absolute;
    z-index: 1;
}

.tooltip:hover .tooltiptext { padding: 5px;
    visibility: visible;
}
 
</style>
<style>
/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 50px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}

/* The Close Button */
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
</style>
</head>
<body>

 


 
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <iframe src="room.php" style="width: 100%; height: 100%;"></iframe>
  </div>

</div>

<div>
 
 <div style="width: 100%; float: right;">
    <?php
    include ('conn.php');

    
    $s=" SELECT * from reservation   ORDER BY sn DESC ";
    
    $rs=mysqli_query($con,$s);
    echo "<table cellpadding='2px' border='1'  >";

    ?>
         <h2  style="text-align: center;" >ALL Reservation RECORDS<button id="myBtn" style="float: right;">Check Rooms</button><hr></h2>

<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
        <center>
        <p  style="background: #2196F3; color: white; text-align: center; font-size: 150%; border-radius: 5px; width: 100%; " >   <?php 
 
 
if(!isset($_SESSION['crfm'])){

    echo "";
} 
 
        if (isset($_SESSION['crfm'])) {
    echo $_SESSION['crfm'];
    unset($_SESSION['crfm']);
	session_destroy();
}
?></p>
</center>
<center>
            <a href="index.php" align="center" >MANAGE BOOKINGS</a> &nbsp; &nbsp; &nbsp;
            <a href="aroom.php" align="center" >ADD ROOMS </a> &nbsp; &nbsp; &nbsp;
            <a href="room.php" align="center">CHECK ROOMS</a> &nbsp; &nbsp; &nbsp; &nbsp;
            <a href="../index.php" align="center">LOGOUT</a>
        </center><hr>
<?php
    echo "<center><b>**Note:</b> Form more details hover/hold the pointer on More Button <br>";
    echo "<center><b>**Note: 1 means YES and 0 means NO.</b><br><br>";
    echo "<tr><th>Recent<th>Booked On<th>EMPLOYEE Name<th>Post<th>EMPLOYEE ID<th>Mob. No.<th>Check IN Date<th>Reference ID<th>Status<th>Details<th>Action";
    $b=0;
    while($r=mysqli_fetch_array($rs))
    {
        $b=1;
     ?>
<tr>
    <td ><?php echo $r['sn']; ?></td>
    <td><?php echo $r['date']; ?></td>
    <td ><?php echo $r['name']; ?></td>
    <td ><?php echo $r['post']; ?></td>
    <td ><?php echo $r['id']; ?></td>
    <td ><?php echo $r['mob']; ?></td>
    <td ><?php echo $r['in_date']; ?></td>
    <td ><?php echo $r['ref']; ?></td>
    <td ><?php echo $r['status']; ?></td>
<td> <p class="tooltip">More
  <span class="tooltiptext" style="text-align: left;"><?php echo "Station: ". $r['house'].  "<br> Days: ". $r['days']. "<br> Room: ". $r['rooms']."<br> Type: ". $r['type']. "<br> Purpose: ". $r['purpose'];  ?></span>
</p>     

</td>

<td><form method="post" action="crfm.php/" > 
<input type="text" name="nam" value="<?php echo $r['name']; ?>" hidden>
<input type="text" name="idate" value="<?php echo $r['in_date']; ?>" hidden>
<input type="text" name="odate" value="<?php echo $r['out_date']; ?>" hidden>
<input type="text" name="omob" value="<?php echo $r['mob']; ?>" hidden>
<input type="text" name="oid" value="<?php echo $r['id']; ?>" hidden>
 <input type="text" name="ref" value="<?php echo $r['ref']; ?>" hidden>
<input type="text" name="uid" value="<?php echo $r['sn']; ?>" hidden>
<input type="text" name="sname" value="<?php echo $r['house']; ?>" hidden>
<input type="text" name="ac" value="<?php echo $r['type']; ?>" hidden>
<input type="tel" name="rnom" style="width: 80px;" placeholder="Room No.">
    <select name="state" >
        <option value="Not Confrim">Not Confrim</option>
        <option value="Confirm">Confirm</option>
        <option value="Wating">Wating</option>
    </select>
    <input type="submit" name="Go" value="GO">
     </form>

    
    </td>
</tr>
     <?php
    if($b==0)
        echo "Records Not Available";
    }
    
    
?> 

<?php 
mysqli_close($con);
    

?>
</div>
</div>
