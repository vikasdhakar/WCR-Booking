
	<br><br><br><br><br><br>
	<center>
		<h1>You are Logout Sucessfully</h1>
		<a href="../login.php">Click here to Login Again</a>
	</center>
	